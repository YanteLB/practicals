#include "wave.h"

namespace wave
{
	double dblEps = 0.0001;
//function start here
	void initArea(arrArea area)
	{
		for(int row = 0; row < intTrows; row++)
		{
			for(int col = 0; col < intTcols; col++)
			{
				double p;
				if(row == 0 && col == 0)
				{
					p = dblEps;
					p = sqrt(p);
					area[row][col] = (sin(p))/(p);
				} else

				{
					p = sqrt(row * row + col * col);
					area[row][col] = (sin(p))/(p);
				}
			}
		}
	}

//function start here
	void showArea(arrArea area, vector<char> &charArray)
	{
		for(int row = 0; row < intTrows; row++)
		{
			for(int col = 0; col < intTcols; col++)
			{
				if( row <= 1 && col <= 1)
				{
					if( (row ==1 && col == 1))
					{
						cout << charArray[char0] << " " ;
					}
					else
					{
							cout << charArray[char1] << " ";
					}
				}
				else
				{
					if(row == 2 || col == 2)
					{
						if( col == 0 || col == 1)
						{
							cout << charArray[char2] << " ";
						}
						else if(row == 0 || row == 1)
						{
							cout << charArray[char2] <<  " ";
						}
						else
						{
						 	if(area[row][col] > 0)
								cout << charArray[char3] << " " ;
							else
								cout << charArray[char4] << " ";
						}

					}
					else
					{
						 if(area[row][col] > 0)
							cout <<charArray[char3] << " " ;
						else
							cout << charArray[char4] << " ";
					}
				}
			}
			cout << endl;
		}
	}



	void  charFuntion(vector<char> &charArray)				//this funtion will change the charactors
	{
		cout << "Enter five characters " << endl;

		for(int i = 0; i < 5; i++)
		{
			cout << "character " << i + 1 << ": ";
            cin  >> charArray[i];
		}
	}

	int validate( int eps)
	{
		while(cin.fail() || eps < 0 || eps == 0 || eps > .09)
		{
			cerr << "Invalid input, Retry(enter a value beteewm[0 -0.9]: ";
			cin >> eps;
		}
		return eps;
	}

	int changeEps()
	{
		cout << "Enter a small value non zero value: ";
		double eps = 0.0;
		cin >> eps;
		eps = validate(eps);

		return eps;
	}
}
