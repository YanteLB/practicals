#include<iostream>
#include<cstdlib>

#include "wave.h"

using namespace std;
using namespace wave;

int main(int argc, char** argv)
{
	vector<char> charVec = { '%', '#', '~', '.', '?'};
	arrArea area;	//defining a area variable
	initArea(area);		//initializing the area

	//main loop
	bool blnContinue = true;
	do
	{
		system("clear");
		showArea(area,charVec);		//displaying the area
		double dblEp = 0.00001;
		cout << "choose an option from the menu " << endl;
		cout << "a) change the symbols " << endl
			 << "b) change the wave " << endl
			 << "x) exit "<< endl;
		char charOption = '\0';
		cin  >> charOption;

		switch(tolower(charOption))
		{
			case 'a':
			{
				charFuntion(charVec);
				break;
			}
			case 'b':
			{
				dblEp = changeEps();
				break;
			}
			case 'x':
			{
				blnContinue = false;
				break;
			}
			default:
			{
				cout << "Invalid option ";
				exit(-1);
			}
		}

	}while(blnContinue);

	return 0;
}
