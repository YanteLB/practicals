#ifndef WAVE_H
#define WAVE_H

#include<cmath>
#include<iostream>
#include<vector>

using namespace std;

namespace wave
{
	//defining constants
	const int intTrows = 25;
	const int intTcols = 53;
	const char char0 = 0;
	const char char1 = 1;
	const char char2 = 2;
	const char char3 = 3;
	const char char4 = 4;

	//customs data
	typedef double arrArea[intTrows][intTcols];

	//function prototypes
	void initArea(arrArea area);		//this function will initialize the area
	void showArea(arrArea area,vector<char> &charVec);//thsi will show the values in the area
	void  charFuntion(vector<char> &charArray);				//this funtion will change the charactors
	int changeEps();			//this function will change epsolon

}
#endif

